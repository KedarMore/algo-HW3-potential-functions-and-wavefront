This code is developed on Python 3.6.9

You can directly run the python files and no inputs are needed.

Exercise 2.py

    python3 Exercise 2.py

    It will plot the potential function and the path from start to goal.

Exercise 3.py

    python3 Exercise 3.py

    It will plot the wave in the workspace till it finds start and plot a path from start to goal.

Exercise 4.py

    python3 Exercise 4.py

    It will plot the wave in the workspace till it finds start and plot a path from start to goal.
    Also it will plot the snapshots of the manipulator position in the workspace.